--[[
    GD50
    Breakout Remake

    -- PlayState Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu

    Represents the state of the game in which we are actively playing;
    player should control the paddle, with the ball actively bouncing between
    the bricks, walls, and the paddle. If the ball goes below the paddle, then
    the player should lose one point of health and be taken either to the Game
    Over screen if at 0 health or the Serve screen otherwise.
]]

PlayState = Class{__includes = BaseState}

--[[
    We initialize what's in our PlayState via a state table that we pass between
    states as we go from playing to serving.
]]
function PlayState:enter(params)
    self.paddle = params.paddle
    self.bricks = params.bricks
    self.health = params.health
    self.score = params.score
    self.highScores = params.highScores
    -- 2.1 - creating table of balls in playstate
    self.balls = {params.ball}
    -- 2.1 - create ball count to keep track of balls
    self.ballcount = 1
    -- 2.1 - create powerup table
    self.powerups = {}
    -- 2.3 - if has key or not
    self.haskey = false
    -- 2.3 - number of locked bricks in play
    self.lockedbricksinplay = params.lockedbricksinplay

    self.level = params.level
    self.powerupcount = math.random(14)
    self.recoverPoints = 5000

    -- give ball random starting velocity,
    -- 2.1 - need set to list
    self.balls[1].dx = math.random(-200, 200)
    self.balls[1].dy = math.random(-50, -60)
end

function PlayState:update(dt)
    if self.paused then
        if love.keyboard.wasPressed('space') then
            self.paused = false
            gSounds['pause']:play()
        else
            return
        end
    elseif love.keyboard.wasPressed('space') then
        self.paused = true
        gSounds['pause']:play()
        return
    end

    -- update positions based on velocity
    self.paddle:update(dt)
    
    -- 2.1 - update balls and collision functionality. have to merge ball collision and bricks 
    -- functionality in a for loop to consider all the balls
    for k, ball in pairs(self.balls) do
        ball:update(dt)

        if ball:collides(self.paddle) then
            -- raise ball above paddle in case it goes below it, then reverse dy
            ball.y = self.paddle.y - 8
            ball.dy = -ball.dy

            --
            -- tweak angle of bounce based on where it hits the paddle
            --

            -- if we hit the paddle on its left side while moving left...
            if ball.x < self.paddle.x + (self.paddle.width / 2) and self.paddle.dx < 0 then
                ball.dx = -50 + -(8 * (self.paddle.x + self.paddle.width / 2 - ball.x))
            
            -- else if we hit the paddle on its right side while moving right...
            elseif ball.x > self.paddle.x + (self.paddle.width / 2) and self.paddle.dx > 0 then
                ball.dx = 50 + (8 * math.abs(self.paddle.x + self.paddle.width / 2 - ball.x))
            end

            gSounds['paddle-hit']:play()
        end

        for i, brick in pairs(self.bricks) do
            -- only check collision if we're in play
            if brick.inPlay and ball:collides(brick) then
                -- 2.1 - set the collision count to increase everytime the ball hits a brick
                self.powerupcount = self.powerupcount + 1
    
                -- add to score
                self.score = self.score + (brick.tier * 200 + brick.color * 25)
    
                -- trigger the brick's hit function, which removes it from play
                brick:hit(self.haskey)
                -- 2.3 - reduce locked bricks in play if they are unlocked
                if brick.locked == true and self.haskey == true then
                    self.score = self.score + 1200
                    self.lockedbricksinplay = self.lockedbricksinplay - 1
                end
    
                -- if we have enough points, recover a point of health
                if self.score > self.recoverPoints then
                    -- can't go above 3 health
                    self.health = math.min(3, self.health + 1)

                    -- 2.2 - paddle increases size when recover points are reached
                    if self.paddle.size < 4 then
                        self.paddle:resize(self.paddle.size + 1)
                    end
    
                    -- multiply recover points by 2
                    self.recoverPoints = math.min(100000, self.recoverPoints * 2)
    
                    -- play recover sound effect
                    gSounds['recover']:play()
                end
    
                -- go to our victory screen if there are no more bricks left
                if self:checkVictory() then
                    gSounds['victory']:play()
    
                    gStateMachine:change('victory', {
                        level = self.level,
                        paddle = self.paddle,
                        health = self.health,
                        score = self.score,
                        highScores = self.highScores,
                        ball = ball,
                        recoverPoints = self.recoverPoints
                    })
                end
    
                --
                -- collision code for bricks
                --
                -- we check to see if the opposite side of our velocity is outside of the brick;
                -- if it is, we trigger a collision on that side. else we're within the X + width of
                -- the brick and should check to see if the top or bottom edge is outside of the brick,
                -- colliding on the top or bottom accordingly 
                --
    
                -- left edge; only check if we're moving right, and offset the check by a couple of pixels
                -- so that flush corner hits register as Y flips, not X flips
                if ball.x + 2 < brick.x and ball.dx > 0 then
                    
                    -- flip x velocity and reset position outside of brick
                    ball.dx = -ball.dx
                    ball.x = brick.x - 8
                
                -- right edge; only check if we're moving left, , and offset the check by a couple of pixels
                -- so that flush corner hits register as Y flips, not X flips
                elseif ball.x + 6 > brick.x + brick.width and ball.dx < 0 then
                    
                    -- flip x velocity and reset position outside of brick
                    ball.dx = -ball.dx
                    ball.x = brick.x + 32
                
                -- top edge if no X collisions, always check
                elseif ball.y < brick.y then
                    
                    -- flip y velocity and reset position outside of brick
                    ball.dy = -ball.dy
                    ball.y = brick.y - 8
                
                -- bottom edge if no X collisions or top collision, last possibility
                else
                    
                    -- flip y velocity and reset position outside of brick
                    ball.dy = -ball.dy
                    ball.y = brick.y + 16
                end
    
                -- slightly scale the y velocity to speed up the game, capping at +- 150
                if math.abs(ball.dy) < 150 then
                    ball.dy = ball.dy * 1.02
                end
    
                -- only allow colliding with one brick, for corners
                break
            end
        end

        if ball.y >= VIRTUAL_HEIGHT then
            if self.ballcount <=1 then
                self.health = self.health - 1
                gSounds['hurt']:play()
                -- 2.2 - paddle resize if lost health
                if self.paddle.size > 1 then
                    self.paddle:resize(self.paddle.size - 1)
                end
    
                if self.health == 0 then
                    gStateMachine:change('game-over', {
                        score = self.score,
                        highScores = self.highScores
                    })
                else
                    gStateMachine:change('serve', {
                        paddle = self.paddle,
                        bricks = self.bricks,
                        health = self.health,
                        score = self.score,
                        highScores = self.highScores,
                        level = self.level,
                        recoverPoints = self.recoverPoints
                    })
                end
            else
                -- 2.1 - remove balls from table that have gone out of bounds
                table.remove(self.balls, k)
                self.ballcount = self.ballcount - 1
            end
        end

    end

    --2.1 - powerup spawn logic, using modulo remainder of zero from a selection of random values
    -- range is a bit bigger than it needs to be, but I was testing values for a reasonable 
    -- rate of spawning. 
    if self.powerupcount % 13 == 0 and self.ballcount < 12 then
        powerbb = Powerup(math.random(0, VIRTUAL_WIDTH - 16), self.paddle.y - 100, 
        -- 2.3 - added needskey to track if key powerup should drop
        (self.lockedbricksinplay > 0) and (not self.haskey))
        table.insert(self.powerups, powerbb)
        self.powerupcount = math.random(1,39)
    end



    -- 2.1 - update and check powerup collision
    for k, powerup in pairs(self.powerups) do
        powerup:update(dt)
        if powerup:collides(self.paddle) then
            --2.3 key powerup update
            if powerup.type == 10 then
                self.haskey = true
                gSounds['confirm']:play()
            else
            self:powerUp()
            end
            table.remove(self.powerups, k)
        end
    
    end
    

    -- for rendering particle systems
    for k, brick in pairs(self.bricks) do
        brick:update(dt)
    end

    if love.keyboard.wasPressed('escape') then
        love.event.quit()
    end

    -- 2.1 - test button for powerup.
    if love.keyboard.wasPressed('b') then
        self:powerUp()
    end
end

function PlayState:render()
    -- render bricks
    for k, brick in pairs(self.bricks) do
        brick:render()
    end

    -- render all particle systems
    for k, brick in pairs(self.bricks) do
        brick:renderParticles()
    end
    -- 2.1 - render powerups
    for k, powerup in pairs(self.powerups) do
        powerup:render()
    end

    self.paddle:render()
    -- 2.1 - render balls
    for k, ball in pairs(self.balls) do
        ball:render()
    end

    renderScore(self.score)
    renderHealth(self.health)

    -- pause text, if paused
    if self.paused then
        love.graphics.setFont(gFonts['large'])
        love.graphics.printf("PAUSED", 0, VIRTUAL_HEIGHT / 2 - 16, VIRTUAL_WIDTH, 'center')
    end
end

function PlayState:checkVictory()
    for k, brick in pairs(self.bricks) do
        if brick.inPlay then
            return false
        end 
    end

    return true
end

-- 2.1 - Multi ball powerup functionality
function PlayState:powerUp()
    ball1 = Ball(math.random(7))
    ball2 = Ball(math.random(7))
    -- 2.1 & 2.2 -- have balls spawn from middle, based on paddle size
    ball1.x = self.paddle.x + (self.paddle.size * 16)
    ball2.x = self.paddle.x + (self.paddle.size * 16)
    ball1.y = self.paddle.y
    ball2.y = self.paddle.y

    ball1.dx = self.balls[1].dx
    ball2.dx = -self.balls[1].dx

    ball1.dy = self.balls[1].dy
    ball2.dy = self.balls[1].dy

    if self.balls[1].dy > 0 then
        ball1.dy = -self.balls[1].dy
        ball2.dy = -self.balls[1].dy
    end

    if self.balls[1].dy < 0 then
        ball1.dy = self.balls[1].dy
        ball2.dy = self.balls[1].dy
    end

    table.insert(self.balls, ball1)
    table.insert(self.balls, ball2)

    self.ballcount = self.ballcount + 2

    gSounds['confirm']:play()

end
