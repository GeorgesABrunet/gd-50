--[[
    GD50
    Super Mario Bros. Remake

    -- LevelMaker Class --

    Author: Colton Ogden
    cogden@cs50.harvard.edu
]]

LevelMaker = Class{}

function LevelMaker.generate(width, height)
    local tiles = {}
    local entities = {}
    local objects = {}

    local tileID = TILE_ID_GROUND
    
    -- whether we should draw our tiles with toppers
    local topper = true
    local tileset = math.random(20)
    local topperset = math.random(20)

    -- 4.2 - defining key and lock aspects
    local haskey = false
    local keycolor = math.random(4)
    local lockcolor = keycolor + 4
    local keylocation = math.random(6, 50)
    local locklocation = math.random(65, 90)

    -- 4.3 - defining pole and flag aspects
    local polecolor = math.random(6)
    local flagcolor = {7, 16, 25, 34}

    -- 4.2 - decided to add a gem counter to make getting gems more rewarding
    local gemcount = 1

    -- insert blank tables into tiles for later access
    for x = 1, height do
        table.insert(tiles, {})
    end

    -- column by column generation instead of row; sometimes better for platformers
    for x = 1, width do
        local tileID = TILE_ID_EMPTY
        
        -- lay out the empty space
        for y = 1, 6 do
            table.insert(tiles[y],
                Tile(x, y, tileID, nil, tileset, topperset))
        end
        -- 4.1 - spawning everything at least 2 or 3 blocks away from start and end
        -- chance to just be emptiness
        if x > 2 and math.random(7) == 1 and x < (width - 3) and (x ~= keylocation) and (x ~= locklocation) then
            for y = 7, height do
                table.insert(tiles[y],
                    Tile(x, y, tileID, nil, tileset, topperset))
            end
        else
            tileID = TILE_ID_GROUND

            local blockHeight = 4

            for y = 7, height do
                table.insert(tiles[y],
                    Tile(x, y, tileID, y == 7 and topper or nil, tileset, topperset))
            end

            -- chance to generate a pillar
            -- 4.2 - make it so key cannot spawn between two pillars
            if math.random(8) == 1 and (x ~= keylocation) and (x ~= keylocation - 1) 
            and (x ~= locklocation) and (x ~= locklocation - 1) then
                blockHeight = 2
                
                -- chance to generate bush on pillar
                if math.random(8) == 1 then
                    table.insert(objects,
                        GameObject {
                            texture = 'bushes',
                            x = (x - 1) * TILE_SIZE,
                            y = (4 - 1) * TILE_SIZE,
                            width = 16,
                            height = 16,
                            
                            -- select random frame from bush_ids whitelist, then random row for variance
                            frame = BUSH_IDS[math.random(#BUSH_IDS)] + (math.random(4) - 1) * 7
                        }
                    )
                end
                
                -- pillar tiles
                tiles[5][x] = Tile(x, 5, tileID, topper, tileset, topperset)
                tiles[6][x] = Tile(x, 6, tileID, nil, tileset, topperset)
                -- 4.1 - initializing x > 2 spawn logic makes this line crash. why?
                tiles[7][x].topper = nil
            
            -- chance to generate bushes
            elseif math.random(8) == 1 then
                table.insert(objects,
                    GameObject {
                        texture = 'bushes',
                        x = (x - 1) * TILE_SIZE,
                        y = (6 - 1) * TILE_SIZE,
                        width = 16,
                        height = 16,
                        frame = BUSH_IDS[math.random(#BUSH_IDS)] + (math.random(4) - 1) * 7,
                        collidable = false
                    }
                )
            end

            -- chance to spawn a block
            -- 4.2 - make it so jumpblocks cannot spawn on lock location
            if (x > 2) and (x ~= locklocation) and math.random(10) == 1 or (x == keylocation) and (x < width - 4) then
                table.insert(objects,

                    -- jump block
                    GameObject {
                        texture = 'jump-blocks',
                        x = (x - 1) * TILE_SIZE,
                        y = (blockHeight - 1) * TILE_SIZE,
                        width = 16,
                        height = 16,

                        -- make it a random variant
                        frame = math.random(#JUMP_BLOCKS),
                        collidable = true,
                        hit = false,
                        solid = true,

                        -- collision function takes itself
                        onCollide = function(obj)

                            -- spawn a gem if we haven't already hit the block
                            if not obj.hit then
                                -- 4.2 - key spawn logic
                                if haskey == false and (x == keylocation) then
                                    local key = GameObject {
                                        texture = 'keysandlocks',
                                        x = (x - 1) * TILE_SIZE,
                                        y = (blockHeight - 1) * TILE_SIZE - 4,
                                        width = 16,
                                        height = 16,
                                        frame = keycolor,
                                        collidable = true,
                                        consumable = true,
                                        solid = false,
                                        -- 4.2 - consuming key gives mucho points
                                        onConsume = function(player, object)
                                            gSounds['pickup']:play()
                                            player.score = player.score + 500
                                            haskey = true
                                        end
                                    }
                                    
                                    -- make the gem move up from the block and play a sound
                                    Timer.tween(0.1, {
                                        [key] = {y = (blockHeight - 2) * TILE_SIZE}
                                    })
                                    gSounds['powerup-reveal']:play()

                                    table.insert(objects, key)
                                    --haskey = true
                                else
                                -- 4.2 - changed gem spawn chance to score multiplier based on frame
                                    -- maintain reference so we can set it to nil
                                    local gem = GameObject {
                                        texture = 'gems',
                                        x = (x - 1) * TILE_SIZE,
                                        y = (blockHeight - 1) * TILE_SIZE - 4,
                                        width = 16,
                                        height = 16,
                                        frame = math.random(#GEMS),
                                        collidable = true,
                                        consumable = true,
                                        solid = false,

                                        -- gem has its own function to add to the player's score
                                        onConsume = function(player, object)
                                            gSounds['pickup']:play()
                                            gemcount = gemcount + 1
                                            player.score = player.score + (50 * gemcount)
                                        end
                                    }
                                    
                                    -- make the gem move up from the block and play a sound
                                    Timer.tween(0.1, {
                                        [gem] = {y = (blockHeight - 2) * TILE_SIZE}
                                    })
                                    gSounds['powerup-reveal']:play()

                                    table.insert(objects, gem)
                                end
                                obj.hit = true
                            end
                            gSounds['empty-block']:play()
                        end
                    }
                )
            -- 4.2 - lock block spawn    
            elseif (x == locklocation) then
                -- lock block object definition
                local lock = GameObject {
                    texture = 'keysandlocks',
                    x = (x - 1) * TILE_SIZE,
                    y = (blockHeight - 1) * TILE_SIZE,
                    width = 16,
                    height = 16,
                    frame = lockcolor,
                    collidable = false,
                    consumable = false,
                    solid = true
                }
                table.insert(objects, lock)

                lock.onCollide = function(obj)
                    -- having the key unlocks the lock, triggering it to disappear on next hit
                    if haskey == true then
                        lock.solid = false
                        lock.consumable = true
                        gSounds['powerup-reveal']:play()
                        lock.onConsume =  function(player, object)
                            gSounds['pickup']:play()
                            player.score = player.score + 500
                            -- 4.3 - consuming lock spawns pole and flag
                            local pole = GameObject {
                                texture = 'poles',
                                x = (width - 2) * TILE_SIZE,
                                y = (blockHeight - 0.5) * TILE_SIZE - 4,
                                width = 16,
                                height = 48,
                                frame = polecolor,
                                collidable = false,
                                consumable = true,
                                solid = false,
                                -- 4.3 - consuming pole gives even more mucho points
                                onConsume = function(player, object)
                                    gSounds['pickup']:play()
                                    player.score = player.score + 1000
                                    -- 4.4 - consuming pole takes us to next level
                                    gStateMachine:change('play', {
                                        level = LevelMaker.generate(width + 10, 10),
                                        score = player.score,
                                        background = math.random(3)
                                    })
                                end
                            }
                            -- flag and pole2 and cannot be interacted with, like the bushes
                            local flag = GameObject {
                                texture = 'flags',
                                x = (width - 1.5) * TILE_SIZE,
                                y = (blockHeight - 0.5) * TILE_SIZE - 4,
                                width = 16,
                                height = 16,
                                frame = flagcolor[math.random(#flagcolor)]
                            }
                            -- pole2 is just for looks, so as player consumes pole and advances, pole2 remains in place
                            local pole2 = GameObject {
                                texture = 'poles',
                                x = (width - 2) * TILE_SIZE,
                                y = (blockHeight - 0.5) * TILE_SIZE - 4,
                                width = 16,
                                height = 48,
                                frame = polecolor
                            }
                            table.insert(objects, pole2)
                            table.insert(objects, pole)
                            table.insert(objects, flag)
                        end  
                   else
                        gSounds['empty-block']:play()
                   end
                end
            end
        end
    end

    local map = TileMap(width, height)
    map.tiles = tiles
    
    return GameLevel(entities, objects, map)
end