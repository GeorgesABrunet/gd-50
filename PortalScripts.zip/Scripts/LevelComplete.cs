﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelComplete : MonoBehaviour {

	// Use this for initialization

	public GameObject uiObject;
	void Start () {
		uiObject.SetActive(false);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
//10.3 - takes in portal gun as collider, UI object is text that appears.
	void OnTriggerEnter (Collider PortalGun) {
			uiObject.SetActive(true);
			
	}
}
