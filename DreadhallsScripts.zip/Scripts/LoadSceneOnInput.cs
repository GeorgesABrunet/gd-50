﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LoadSceneOnInput : MonoBehaviour {

	//9.2 - Current scene so script can be called on scene
	public static string CurrentScene;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetAxis("Submit") == 1) {
			CurrentScene = SceneManager.GetActiveScene().name;
			if (CurrentScene == "Title"){
				SceneManager.LoadScene("Play");
			}
			// 9.2 - game over loads title scene
			else if (CurrentScene == "GameOver"){
				SceneManager.LoadScene("Title");
			}
		}
	}
}
