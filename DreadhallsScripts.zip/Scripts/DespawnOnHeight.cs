﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DespawnOnHeight : MonoBehaviour {

	// Use this for initialization
	//9.2 Camera falling below certain y-axis value triggers game over
	public static Vector3 CameraYCoordinates;

	private AudioSource ShushWhispers;

	void Start () {
		ShushWhispers = DontDestroy.instance.GetComponents<AudioSource>()[0];

	}
	
	// Update is called once per frame
	void Update () {
		CameraYCoordinates = Camera.main.gameObject.transform.position;
		if (CameraYCoordinates.y < -10){
			MazeLevel.level = 0;
			Destroy(ShushWhispers);
			DontDestroy.instance = null;
			SceneManager.LoadScene("GameOver");

        }
	}
}
