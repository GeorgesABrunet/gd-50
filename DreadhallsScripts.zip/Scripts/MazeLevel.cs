﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//9.3 - keeping track of level
public class MazeLevel : MonoBehaviour {

	// Use this for initialization
	public static Text CurrentLevel;
		public static int level;
	void Start () {
		//level = 0;
		GameObject DisplayLevel = GameObject.Find("Display Level");
		CurrentLevel = DisplayLevel.GetComponent<Text>();

	}
	
	// Update is called once per frame
	void Update () {
		CurrentLevel.text = "Level: " + level.ToString();
	}
}
