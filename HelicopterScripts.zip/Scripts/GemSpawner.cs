﻿using System.Collections;
//using System.Collections.Generic;
using UnityEngine;

// 8.1 - gem spawner script
public class GemSpawner : MonoBehaviour
{
    public GameObject[] prefabs;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(SpawnGems());
    }

    void Update()
    {
        
    }

    IEnumerator SpawnGems() {
		while (true) {
			int GemsThisRow = Random.Range(1, 2);

			for (int i = 0; i < GemsThisRow; i++) {
				Instantiate(prefabs[Random.Range(0, prefabs.Length)], new Vector3(26, Random.Range(-10, 10), 10), Quaternion.identity);
			}

			// longer wait time to spawn
            yield return new WaitForSeconds(Random.Range(5, 10));
		}
	}
}
