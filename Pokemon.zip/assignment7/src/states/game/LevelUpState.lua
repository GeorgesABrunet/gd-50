--[[
    Level Up Menu State
]]

LevelUpState = Class{__includes = BaseState}

function LevelUpState:init(battleState, pokemon, closeMenu)
    self.battleState = battleState
    self.pokemon = pokemon
    self.closeMenu = closeMenu
    self.OldHP = self.pokemon.HP
    self.OldAttack = self.pokemon.attack
    self.OldDefense = self.pokemon.defense
    self.OldSpeed = self.pokemon.speed
    
    gSounds['levelup']:play()
    self.pokemon:levelUp()

    self.LevelUpMenu = Menu{
        x = VIRTUAL_WIDTH - 180,
        y = 0,
        width = 180,
        height = 2 * VIRTUAL_HEIGHT/3,
        items = {
            {
                text = 'HP:  ' .. self.OldHP .. ' + ' .. (self.pokemon.HP - self.OldHP) .. ' = ' .. self.pokemon.HP
            },
            {
                text = 'ATK: ' .. self.OldAttack .. ' + ' .. (self.pokemon.attack - self.OldAttack) .. ' = ' .. self.pokemon.attack
            },
            {
                text = 'DEF: ' .. self.OldDefense .. ' + ' .. (self.pokemon.defense - self.OldDefense) .. ' = ' .. self.pokemon.defense
            },
            {
                text = 'SPD: ' .. self.OldSpeed .. ' + ' .. (self.pokemon.speed - self.OldSpeed) .. ' = ' .. self.pokemon.speed
            }
        },
        CursorOn = false
    }

end

function LevelUpState:update(dt)
    self.LevelUpMenu:update(dt)

    if love.keyboard.wasPressed('enter') or love.keyboard.wasPressed('return') then
        gStateStack:pop()
        self.closeMenu()
    end
end

function LevelUpState:render()
    self.LevelUpMenu:render()
end